// Toggle Menu Hamburger di HP
const mobileMenu = document.getElementById('mobile-menu');
const navLinks = document.querySelector('.nav-links');

mobileMenu.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

// Filter Katalog Buku
const filterButtons = document.querySelectorAll('.filter-btn');
const bookCards = document.querySelectorAll('.book-card');

filterButtons.forEach(button => {
    button.addEventListener('click', () => {
        filterButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        const filter = button.getAttribute('data-filter');

        bookCards.forEach(card => {
            if (filter === 'all' || card.getAttribute('data-category') === filter) {
                card.style.display = 'flex';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// Pencarian Buku
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');

function performSearch() {
    const query = searchInput.value.toLowerCase();
    bookCards.forEach(card => {
        const title = card.querySelector('h3').textContent.toLowerCase();
        const author = card.querySelector('.author').textContent.toLowerCase();
        if (title.includes(query) || author.includes(query)) {
            card.style.display = 'flex';
        } else {
            card.style.display = 'none';
        }
    });
}

searchBtn.addEventListener('click', performSearch);
searchInput.addEventListener('keyup', (e) => {
    if (e.key === 'Enter') {
        performSearch();
    }
});

// --- SISTEM PEMINJAMAN & READER ---

let borrowedBooks = JSON.parse(localStorage.getItem('borrowedBooks')) || [];
let currentBookPages = [];
let currentPageIndex = 0;

// Modal Notifikasi Umum
const modal = document.getElementById('modal');
const closeBtn = document.querySelector('.close-btn');
const modalMessage = document.getElementById('modalMessage');

closeBtn.addEventListener('click', () => { modal.style.display = 'none'; });
window.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });

// Fungsi Pinjam Buku
function borrowBook(title, pagesArray) {
    const isAlreadyBorrowed = borrowedBooks.some(book => book.title === title);
    if (isAlreadyBorrowed) {
        modalMessage.textContent = `Buku "${title}" sudah ada di daftar pinjaman Anda!`;
        modal.style.display = 'flex';
        return;
    }

    borrowedBooks.push({ title, pages: pagesArray });
    saveAndRender();

    modalMessage.textContent = `Berhasil! Buku "${title}" ditambahkan ke menu Dipinjam.`;
    modal.style.display = 'flex';
}

// Fungsi Kembalikan Buku
function returnBook(title) {
    borrowedBooks = borrowedBooks.filter(book => book.title !== title);
    saveAndRender();
}

function saveAndRender() {
    localStorage.setItem('borrowedBooks', JSON.stringify(borrowedBooks));
    renderBorrowedBooks();
}

// Render Daftar Buku Dipinjam
function renderBorrowedBooks() {
    const borrowedList = document.getElementById('borrowedList');
    const borrowCount = document.getElementById('borrowCount');
    
    borrowCount.textContent = borrowedBooks.length;
    borrowedList.innerHTML = '';

    if (borrowedBooks.length === 0) {
        borrowedList.innerHTML = '<p id="emptyMessage" class="empty-text">Belum ada buku yang dipinjam.</p>';
        return;
    }

    borrowedBooks.forEach((book) => {
        const card = document.createElement('div');
        card.className = 'book-card';
        card.innerHTML = `
            <div class="book-img green-theme"><i class="fa-solid fa-book-open"></i></div>
            <div class="book-info">
                <span class="category-tag green">Dipinjam</span>
                <h3>${book.title}</h3>
                <p class="desc">Buku digital siap dibaca per halaman secara online.</p>
                <button class="btn-read" onclick="openReader('${book.title.replace(/'/g, "\\'")}')"><i class="fa-solid fa-glasses"></i> Baca Buku</button>
                <button class="btn-return" onclick="returnBook('${book.title.replace(/'/g, "\\'")}')">Kembalikan</button>
            </div>
        `;
        borrowedList.appendChild(card);
    });
}

// Reader Modal Logic
const readerModal = document.getElementById('readerModal');
const readerTitle = document.getElementById('readerTitle');

function openReader(title) {
    const book = borrowedBooks.find(b => b.title === title);
    if (book && book.pages && book.pages.length > 0) {
        readerTitle.textContent = book.title;
        currentBookPages = book.pages;
        currentPageIndex = 0;
        renderPage();
        readerModal.style.display = 'flex';
    }
}

function renderPage() {
    const readerBody = document.getElementById('readerBody');
    const pageIndicator = document.getElementById('pageIndicator');
    const prevPageBtn = document.getElementById('prevPageBtn');
    const nextPageBtn = document.getElementById('nextPageBtn');

    readerBody.innerHTML = currentBookPages[currentPageIndex];
    pageIndicator.textContent = `Halaman ${currentPageIndex + 1} dari ${currentBookPages.length}`;

    prevPageBtn.disabled = currentPageIndex === 0;
    nextPageBtn.disabled = currentPageIndex === currentBookPages.length - 1;
}

function changePage(direction) {
    const newIndex = currentPageIndex + direction;
    if (newIndex >= 0 && newIndex < currentBookPages.length) {
        currentPageIndex = newIndex;
        renderPage();
        document.getElementById('readerBody').scrollTop = 0;
    }
}

function closeReader() {
    readerModal.style.display = 'none';
}

window.addEventListener('click', (e) => {
    if (e.target === readerModal) {
        readerModal.style.display = 'none';
    }
});

// Jalankan saat pertama kali dimuat
renderBorrowedBooks();
